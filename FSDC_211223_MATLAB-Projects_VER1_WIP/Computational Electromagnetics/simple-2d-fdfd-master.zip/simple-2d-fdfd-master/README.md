# simple-2d-fdfd
Matlab fdfd code for computing the propagating field at a given wavelength in arbitrary 2D photonic crystal structures.

This project vastly benefitted from the great [computational electromagnetics course](http://www.dropwizard.io/1.0.2/docs/) by Pr. Rumpf.

